starjavapos_StarPRNT_windows
Ver 1.13.12
---------------------------------------

Package Contents:
    . starjavapos.jar
    . stario.jar
    . CommandEmulator.jar
    . jpos113-controls.jar
    . jcl.jar
    . xercesimpl.jar
    . xml-apis.jar
    . jpos.xml
    . StarReceiptTest.java
    . StarCashDrawerTest.java
    . star.gif
    . StarIOJ.dll
    . StarIOPort.dll
    . SoftwareLicenseAgreement.pdf
    . SoftwareLicenseAgreement_jp.pdf
    . SoftwareLicenseAgreementAppendix.pdf
    . readme_en.txt
    . readme_jp.txt
    . USBVendorClassDriver
    . DiscoveryTool


Java Virtual Machine Requirement:
    Java2 Standard Edition 1.4.2 or higher

    NOTE: We recommend using Java2 Standard Edition 5.0 or higher


Configuration Sample - jpos.xml:
    StarJavaPOS uses the JCL - Java Configuration Loader system for
    configuring the provided services.  The file jpos.xml contained
    in this package has been initialized with device entries for
    Star's newest printer products.

    The following is a list of the POSPrinter device entries
    contained in this file as indexed by their logicalName field:
        . POSPrinter_windows_usb_printer_class
        . POSPrinter_windows_ethernet
        . POSPrinter_windows_bluetooth

    The following is a list of the CashDrawer device entries
    contained in this file as indexed by their logicalName field:
        . CashDrawer_windows_usb_printer_class
        . CashDrawer_windows_ethernet
        . CashDrawer_windows_bluetooth

    The following is an adding property of POSPrinter
        . useNVBitImage
        example:  <prop name="useNVBitImage" type="Boolean" value="true" />
    NOTE: If "useNVLogoImage property" set the "true", can use "NV Logo Print" by escape sequence(ESC | # B). 


    Please refer to starjavapos_sm_en.pdf for details.


Usage - Test Application:
    Open StarReceiptTest.java and StarCashDrawerTest.java.
    Then, refer to the usage instructions.


Release History

18/06/2018 First Release.
Ver 1.13.10

04/09/2019 Bug Fix:cannot control multiple CashDrawer devices simultaneously.
ver1.13.11

27/08/2019  Integrated JavaPOS Driver for mCollection and Portable.
Ver 1.13.12  - Add support MCP30.
